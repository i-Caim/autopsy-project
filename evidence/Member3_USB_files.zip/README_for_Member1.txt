IS1489 Autopsy - Member 3 (Layan) test files for the USB image
================================================================

Please copy these 3 files onto the USB with everyone else's files,
BEFORE you delete them and quick-format the drive.
Do not open, unzip, or rename them.

1) holiday_photo.jpg
   A harmless Windows program (.exe) renamed to .jpg.
   It only prints a message. Shows: Extension Mismatch, File Type ID, Hash Lookup.
   MD5: c83acc0a219ac1852fd8bf74ae022936

2) secret_plans.zip
   Password-protected ZIP (AES-256). Password: IS1489demo
   Shows: Encryption Detection.
   MD5: ced88f72da5f18bdb87c8ba30d75e3bf

3) project_archive.zip
   Normal ZIP with 3 files inside: meeting_notes.txt, budget.csv, team_diagram.png
   Shows: Embedded File Extractor.
   MD5: 0812ae9bda5b2474623c13b09bcbe86c

After loading: check the MD5s match (e.g. certutil -hashfile <file> MD5 on Windows),
so we know nothing changed the files on the way.
If Windows Defender warns about holiday_photo.jpg, allow it - it is our own test program.
